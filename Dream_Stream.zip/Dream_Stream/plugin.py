# -*- coding: utf-8 -*-
from enigma import eServiceReference, eUriResolver, StringList
from Components.config import config
from Plugins.Plugin import PluginDescriptor
from Tools.Log import Log

from api import Stalker as un_us_ed
from stalker import Identity
from StalkerChannels import StalkerChannelSelection
from StalkerConfig import StalkerConfig
from Menu import Dream_StreamMainMenu  # <-- CHANGEMENT ICI
# ---------- FIX : pour MessageBox ----------
from Screens.MessageBox import MessageBox
import traceback

class StalkerUriResolver(eUriResolver):
    _schemas = ("stalker",)
    instance = None
    def __init__(self):
        Log.w(self._schemas)
        eUriResolver.__init__(self, StringList(self._schemas))

    def resolve(self, service, uri):
        Log.w(uri)
        def onUriReady(uri):
            Log.w()
            if not service.ptrValid():
                return
            if uri:
                service.setResolvedUri(uri, eServiceReference.idDVB)
            else:
                service.failedToResolveUri()
        StalkerChannelSelection.stalker.resolveUri(uri, onUriReady)
        return True

def isBouquetAndOrRoot(csel):
    inBouquet = csel.getMutableList() is not None
    current_root = csel.getRoot()
    current_root_path = current_root and current_root.getPath()
    inBouquetRootList = current_root_path and current_root_path.find('FROM BOUQUET "bouquets.') != -1
    Log.w("inBouquet: %s, current_root_path %s, inBouquetRootList %s" % (inBouquet, current_root_path, inBouquetRootList))
    return (inBouquet, inBouquetRootList)

def check_channel(csel):
    inBouquet, inBouquetRootList = isBouquetAndOrRoot(csel)
    return inBouquet and not inBouquetRootList

def check_group(csel):
    inBouquet, inBouquetRootList = isBouquetAndOrRoot(csel)
    return inBouquetRootList

def main_channellist(session, ref, csel, **kwargs):
    Log.i(kwargs)
    if ref:
        session.openWithCallback(onChannelSelected, StalkerChannelSelection, csel)

def onChannelSelected(csel, data, bouquetName=None):
    if bouquetName:
        csel.addBouquet(bouquetName, data)
        return
    if csel.inBouquet() and data:
        if isinstance(data, eServiceReference):
            csel.addServiceToBouquet(csel.getRoot(), service=data)

# ---------- FIX : try/extern autour de l'ouverture ----------
def main(session, **kwargs):
    try:
        session.open(Dream_StreamMainMenu)
    except Exception:
        Log.w("Dream_Stream main crash : " + traceback.format_exc())
        session.open(MessageBox,
                     _("Dream_Stream : impossible d'ouvrir le menu.\n"
                       "Vérifiez le fichier log."), MessageBox.TYPE_ERROR)

def setup(session, **kwargs):
    session.open(StalkerConfig)

# ---------- FIX : fonction filtrant menuid (évite l'appel intempestif) ----------
def mainmenu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(_("Dream_Stream"), main, "dreamstream", 70)]
    return []

def onLoginSuccess():
    Log.w(StalkerChannelSelection.stalker.reload())
    StalkerChannelSelection.stalker.onLoginSuccess.remove(onLoginSuccess)

def configChanged(unused):
    Log.w("Dream_Stream config changed, reloading")
    login()

def login():
    Log.i("Starting Dream_Stream")
    if not onLoginSuccess in StalkerChannelSelection.stalker.onLoginSuccess:
        StalkerChannelSelection.stalker.onLoginSuccess.append(onLoginSuccess)
    try:
        mac = config.stalker_client.portals[config.stalker_client.portal.value].portal.value.split('mac=')[-1]
    except:
        mac = '00:1A:79:3D:8F:01'
    Log.i('Dream_Stream starting '+str(config.stalker_client.portals[config.stalker_client.portal.value].portal.value))
    Log.i('Dream_Stream starting'+str(mac))
    StalkerChannelSelection.stalker.login(Identity(mac, "en_GB.utf8", "Europe/Berlin"))

def autostart(reason, *args, **kwargs):
    if not reason:
        config.stalker_client.portal.addNotifier(configChanged, initial_call=False, immediate_feedback=False)
        login()
        StalkerUriResolver.instance = StalkerUriResolver()
        eUriResolver.addResolver(StalkerUriResolver.instance)

def Plugins(path, **kwargs):
    global plugin_path
    plugin_path = path
    return [
        PluginDescriptor(
            name=_("Dream_Stream Autostart"),
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart),
        PluginDescriptor(
            name=_("Dream_Stream"),
            description=_("Accéder à Dream_Stream et sa configuration"),
            where=[PluginDescriptor.WHERE_PLUGINMENU],
            icon="plugin.png",
            fnc=main),
        # ---------- FIX : WHERE_MENU séparé et filtré ----------
        PluginDescriptor(
            name=_("Dream_Stream"),
            where=PluginDescriptor.WHERE_MENU,
            fnc=mainmenu),
        PluginDescriptor(
            name=_("Ajouter chaîne Dream_Stream"),
            description=_("Add Dream_Stream Channel"),
            where=PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
            fnc=main_channellist,
            helperfnc=check_channel,
            icon="plugin.png"),
        PluginDescriptor(
            name=_("Ajouter groupe Dream_Stream"),
            description=_("Add Dream_Stream Group"),
            where=PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
            fnc=main_channellist,
            helperfnc=check_group,
            icon="plugin.png"),
    ]